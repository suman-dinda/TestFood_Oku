
var krms_config ={	
	'ApiUrl' : "http://foodoku.in/mobileapp/api",
	'DialogDefaultTitle' : "Foodoku",
	'pushNotificationSenderid' : "973044842925",
	'facebookAppId' : "851850738291440",
	'APIHasKey' : "88ee6952dab7af0363d233510ce07b7fd00e04769bf4f123cadc5234df1d7922"
};